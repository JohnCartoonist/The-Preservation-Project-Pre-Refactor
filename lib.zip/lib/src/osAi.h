#ifndef _OSAI_H_
#define _OSAI_H_

s32 osAiSetFrequency(u32);
s32 osAiSetNextBuffer(void *, u32);
u32 osAiGetLength(void);
#endif
