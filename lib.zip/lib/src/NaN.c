typedef union {
    int i;
    float f;
} fu;
const fu NAN = { 0x7f810000 };
