#ifndef GFX_OUTPUT_BUFFER_H
#define GFX_OUTPUT_BUFFER_H

extern u64 gGfxSPTaskOutputBuffer[0x3e00];

#endif
