#ifndef ZBUFFER_H
#define ZBUFFER_H

#include "types.h"
#include "config.h"

extern u16 gZBuffer[SCREEN_WIDTH * SCREEN_HEIGHT];

#endif
