#include <ultra64.h>

u64 gAudioGlobalsEndMarker;
