#ifndef SKIN_MOVEMENT_H
#define SKIN_MOVEMENT_H

#include "gd_types.h"

extern void func_80181760(struct ObjGroup *);
extern void move_skin(struct ObjNet *);
extern void func_80181894(struct ObjJoint *);
extern void Unknown80181B88(struct ObjJoint *);

#endif /* SKIN_MOVEMENT_H */
