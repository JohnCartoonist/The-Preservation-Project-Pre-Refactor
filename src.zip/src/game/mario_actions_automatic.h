#ifndef _MARIO_ACTIONS_AUTOMATIC_H
#define _MARIO_ACTIONS_AUTOMATIC_H

s32 mario_execute_automatic_action(struct MarioState *m);

#endif /* _MARIO_ACTIONS_AUTOMATIC_H */
