#ifndef _DECOMPRESS_H
#define _DECOMPRESS_H

#include "types.h"

extern void decompress(void *, void *);

#endif /* _DECOMPRESS_H */
