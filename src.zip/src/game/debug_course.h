#ifndef _DEBUG_COURSE_H
#define _DEBUG_COURSE_H

void nop_change_course(void);

#endif
