#ifndef _MARIO_ACTIONS_AIRBORNE_H
#define _MARIO_ACTIONS_AIRBORNE_H

struct MarioState;

s32 mario_execute_airborne_action(struct MarioState *m);

#endif /* _MARIO_ACTIONS_AIRBORNE_H */
