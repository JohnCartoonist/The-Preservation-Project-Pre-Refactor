#include <ultra64.h>

#include "sm64.h"

// This is a seperate file according to Europe/Shindou
// versions. It is unknown what this file was for.

void nop_change_course(void) {
}
