#ifndef _MAIN_ENTRY_H
#define _MAIN_ENTRY_H

#include "types.h"

extern u8 _entrySegmentRomStart[];
extern u8 _entrySegmentRomEnd[];

#endif /* _MAIN_ENTRY_H */
