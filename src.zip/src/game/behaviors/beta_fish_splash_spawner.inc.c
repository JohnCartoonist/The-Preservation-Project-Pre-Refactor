/**
 * Behavior for bhvBetaFishSplashSpawner.
 * This is a now non-functional fish splash object found in WF
 * that can be seen in Shoshinkai 1995 footage. It used to create
 * a fish that would splash up when the player walked through it.
 * This functionality was probably moved; in the final game,
 * an identical fish splash can occur with a 1/256 chance every time
 * Mario splashes in water.
 */

struct WaterSplashParams fishEasterEggSplash = { 34,   MODEL_FISH, bhvWaterDrops, 0,    0,   2.0f,
                                        3.0f, 20.0f,      20.0f,         1.0f, 0.0f };

/**
 * Update function for bhvBetaFishSplashSpawner.
 */
void bhv_beta_fish_splash_spawner_loop(void) {
    //UNUSED u8 pad[12];
    //UNUSED f32 water_level = find_water_level(o->oPosX, o->oPosZ);
    struct Object *fishEasterEggObject;

    if (o->oDistanceToMario < 150.0f) {
        if ((gMarioStates->action == ACT_JUMP || gMarioStates->action == ACT_DOUBLE_JUMP || gMarioStates->action == ACT_TRIPLE_JUMP) && !(o->oFlags & 0x8)) {
            o->oFlags |= 0x8;

            fishEasterEggObject = spawn_water_splash(gMarioObject, &fishEasterEggSplash);
            func_8029EE20(fishEasterEggObject, blue_fish_seg3_anims_0301C2B0, 0);
        }
    } else if (o->oDistanceToMario > 500.0f) {
        o->oFlags &= ~0x8;
    }
}
