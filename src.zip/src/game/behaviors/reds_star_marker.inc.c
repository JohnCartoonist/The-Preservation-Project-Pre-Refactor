
// Filename is abbreviated to prevent compiler seg fault

void bhv_red_coin_star_marker_init(void) {
    o->header.gfx.scale[2] = 0.75f;
}
