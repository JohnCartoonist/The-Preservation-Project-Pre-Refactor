// sound_waterfall.inc.c

void bhv_waterfall_sound_loop(void) {
    PlaySound(SOUND_ENV_WATERFALL2);
}
