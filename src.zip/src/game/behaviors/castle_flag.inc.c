// castle_flag.inc.c

void bhv_castle_flag_init(void) {
    o->header.gfx.unk38.animFrame = RandomFloat() * 28.0f;
}
