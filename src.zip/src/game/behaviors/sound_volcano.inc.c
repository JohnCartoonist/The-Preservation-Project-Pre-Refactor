// sound_volcano.inc.c

void bhv_volcano_sound_loop(void) {
    PlaySound(SOUND_ENV_DRONING1);
}
