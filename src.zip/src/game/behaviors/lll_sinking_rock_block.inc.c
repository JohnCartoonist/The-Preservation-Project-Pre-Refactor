// lll_sinking_rock_block.c.inc

void bhv_lll_sinking_rock_block_loop(void) {
    func_802BB680(&o->oSinkWhenSteppedOnUnk104, &o->oSinkWhenSteppedOnUnk108, 124, -110);
    o->oGraphYOffset = 0.0f;
    o->oPosY = o->oHomeY + o->oSinkWhenSteppedOnUnk108;
}
