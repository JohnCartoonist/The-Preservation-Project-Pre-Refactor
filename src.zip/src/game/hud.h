#ifndef HUD_H
#define HUD_H

#include "types.h"

enum PowerMeterAnimation {
    POWER_METER_HIDDEN,
    POWER_METER_EMPHASIZED,
    POWER_METER_DEEMPHASIZING,
    POWER_METER_HIDING,
    POWER_METER_VISIBLE
};

enum MinimapAnimation {
    MINIMAP_HIDDEN,
    MINIMAP_HIDING,
    MINIMAP_VISIBLE,
    MINIMAP_APPEARING
};

// Segment 3
extern Gfx* dl_power_meter_eight;
extern Gfx* dl_power_meter_seven;
extern Gfx* dl_power_meter_six;
extern Gfx* dl_power_meter_five;
extern Gfx* dl_power_meter_four;
extern Gfx* dl_power_meter_three;
extern Gfx* dl_power_meter_two;
extern Gfx* dl_power_meter_one;
extern Gfx* dl_power_meter_zero;
extern Gfx* dl_minimap_arrow;
extern Gfx* dl_minimap_wf;
extern Gfx* dl_minimap_lll;

// Functions
extern void render_hud(void);

#endif /* HUD_H */
