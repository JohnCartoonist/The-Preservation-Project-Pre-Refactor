#ifndef _OBJECT_COLLISION_H
#define _OBJECT_COLLISION_H

#include "types.h"

// extern ? Unknown802C8460(?);
// extern ? func_802C8504(?);
// extern ? func_802C870C(?);
// extern ? func_802C88A8(?);
// extern ? func_802C8918(?);
// extern ? func_802C89CC(?);
// extern ? func_802C8AD4(?);
// extern ? func_802C8B50(?);
extern void detect_object_collisions(void);

#endif /* _OBJECT_COLLISION_H */
