#ifndef _MARIO_ACTIONS_SUBMERGED_H
#define _MARIO_ACTIONS_SUBMERGED_H

struct MarioState;

s32 mario_execute_submerged_action(struct MarioState *m);

#endif /* _MARIO_ACTIONS_SUBMERGED_H */
