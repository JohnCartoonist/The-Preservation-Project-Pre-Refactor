#ifndef _LEVEL_SELECT_MENU_H
#define _LEVEL_SELECT_MENU_H

#include "types.h"

extern s32 LevelProc_8016F508(s16 arg1, s32 arg2);

#endif /* _LEVEL_SELECT_MENU_H */
