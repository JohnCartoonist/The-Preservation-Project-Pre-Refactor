#ifndef _HELPER_MACROS_H
#define _HELPER_MACROS_H

#define LIST_NEXT_ITEM(curItem, type) ((type *)((s32)curItem + sizeof(type)))

#endif 
