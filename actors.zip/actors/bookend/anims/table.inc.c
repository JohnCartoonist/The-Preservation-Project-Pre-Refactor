// 0x05002540
const struct Animation *const bookend_seg5_anims_05002540[] = {
    &bookend_seg5_anim_05002528,
    &bookend_seg5_anim_050023F4,
    &bookend_seg5_anim_05002510,
    NULL,
};
