#include <ultra64.h>
#include "sm64.h"
#include "geo_commands.h"

#include "make_const_nonconst.h"

#include "common1.h"
#include "group6.h"

#include "monty_mole/geo.inc.c"
#include "ukiki/geo.inc.c"
#include "fwoosh/geo.inc.c"
