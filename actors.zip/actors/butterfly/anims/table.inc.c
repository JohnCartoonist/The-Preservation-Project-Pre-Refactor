// 0x030056B0
const struct Animation *const butterfly_seg3_anims_030056B0[] = {
    &butterfly_seg3_anim_030055B0,
    &butterfly_seg3_anim_03005698,
};
