// 0x0600A4D4
const struct Animation *const seaweed_seg6_anims_0600A4D4[] = {
    &seaweed_seg6_anim_0600A4BC,
};
