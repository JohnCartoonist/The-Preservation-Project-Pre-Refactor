// 0x05009B14
const struct Animation *const mad_piano_seg5_anims_05009B14[] = {
    &mad_piano_seg5_anim_05009A04,
    &mad_piano_seg5_anim_05009AFC,
    NULL,
};
