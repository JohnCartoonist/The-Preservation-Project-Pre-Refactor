// 0x1600013C
const GeoLayout yellow_coin_geo[] = {
   GEO_SHADOW(SHADOW_CIRCLE_4_VERTS, 0xB4, 80),
   GEO_OPEN_NODE(),
      GEO_SWITCH_CASE(8, geo_switch_anim_state),
      GEO_OPEN_NODE(),
         GEO_DISPLAY_LIST(LAYER_ALPHA, coin_seg3_dl_03007800),
         GEO_DISPLAY_LIST(LAYER_ALPHA, coin_seg3_dl_03007800),
         GEO_DISPLAY_LIST(LAYER_ALPHA, coin_seg3_dl_03007828),
         GEO_DISPLAY_LIST(LAYER_ALPHA, coin_seg3_dl_03007828),
         GEO_DISPLAY_LIST(LAYER_ALPHA, coin_seg3_dl_03007850),
         GEO_DISPLAY_LIST(LAYER_ALPHA, coin_seg3_dl_03007850),
         GEO_DISPLAY_LIST(LAYER_ALPHA, coin_seg3_dl_03007878),
         GEO_DISPLAY_LIST(LAYER_ALPHA, coin_seg3_dl_03007878),
      GEO_CLOSE_NODE(),
   GEO_CLOSE_NODE(),
   GEO_END(),
};

// 0x160001A0
const GeoLayout yellow_coin_solid_shadow_geo[] = {
   GEO_SHADOW(SHADOW_CIRCLE_4_VERTS, 0xE0, 80),
   GEO_OPEN_NODE(),
      GEO_SWITCH_CASE(8, geo_switch_anim_state),
      GEO_OPEN_NODE(),
         GEO_DISPLAY_LIST(LAYER_ALPHA, coin_seg3_dl_03007800),
         GEO_DISPLAY_LIST(LAYER_ALPHA, coin_seg3_dl_03007800),
         GEO_DISPLAY_LIST(LAYER_ALPHA, coin_seg3_dl_03007828),
         GEO_DISPLAY_LIST(LAYER_ALPHA, coin_seg3_dl_03007828),
         GEO_DISPLAY_LIST(LAYER_ALPHA, coin_seg3_dl_03007850),
         GEO_DISPLAY_LIST(LAYER_ALPHA, coin_seg3_dl_03007850),
         GEO_DISPLAY_LIST(LAYER_ALPHA, coin_seg3_dl_03007878),
         GEO_DISPLAY_LIST(LAYER_ALPHA, coin_seg3_dl_03007878),
      GEO_CLOSE_NODE(),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
