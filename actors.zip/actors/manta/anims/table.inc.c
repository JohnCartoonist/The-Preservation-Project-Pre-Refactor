// 0x05008EB4
const struct Animation *const manta_seg5_anims_05008EB4[] = {
    &manta_seg5_anim_05008CFC,
    NULL,
    NULL,
};
