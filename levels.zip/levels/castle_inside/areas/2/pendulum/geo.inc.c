// 0x0E001518
const GeoLayout castle_geo_001518[] = {
   GEO_CULLING_RADIUS(600),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, inside_castle_seg7_dl_070512F8),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
