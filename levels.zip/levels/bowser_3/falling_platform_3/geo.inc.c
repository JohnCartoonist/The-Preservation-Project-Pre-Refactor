// 0x0E0002C0
const GeoLayout bowser_3_geo_0002C0[] = {
   GEO_CULLING_RADIUS(5000),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bowser_3_seg7_dl_07002918),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
