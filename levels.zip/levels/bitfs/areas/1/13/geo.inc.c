// 0x0E0005B8
const GeoLayout bitfs_geo_0005B8[] = {
   GEO_CULLING_RADIUS(1300),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bitfs_seg7_dl_070095E0),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
