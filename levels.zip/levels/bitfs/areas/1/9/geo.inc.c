// 0x0E000558
const GeoLayout bitfs_geo_000558[] = {
   GEO_CULLING_RADIUS(4600),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bitfs_seg7_dl_07007720),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
