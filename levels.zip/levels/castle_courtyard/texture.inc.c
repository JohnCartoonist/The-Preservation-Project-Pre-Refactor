ALIGNED8 static const u8 castle_courtyard_seg7_texture_07000000[] = {
#include "levels/castle_courtyard/0.rgba16.inc.c"
};
