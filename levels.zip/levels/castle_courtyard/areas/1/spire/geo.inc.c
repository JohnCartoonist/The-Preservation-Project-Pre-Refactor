// 0x0E000200
const GeoLayout castle_courtyard_geo_000200[] = {
   GEO_CULLING_RADIUS(2600),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, castle_courtyard_seg7_dl_07005078),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
