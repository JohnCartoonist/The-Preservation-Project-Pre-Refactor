// 0x0E0004D8
const GeoLayout bits_geo_0004D8[] = {
   GEO_CULLING_RADIUS(1600),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_ALPHA, bits_seg7_dl_07008FE8),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
