// 0x0E000460
const GeoLayout bits_geo_000460[] = {
   GEO_CULLING_RADIUS(3900),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bits_seg7_dl_07005DB8),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
