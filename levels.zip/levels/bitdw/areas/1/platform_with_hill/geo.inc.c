// 0x0E000468
const GeoLayout geo_bitdw_000468[] = {
   GEO_CULLING_RADIUS(2900),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bitdw_seg7_dl_07005BC0),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
