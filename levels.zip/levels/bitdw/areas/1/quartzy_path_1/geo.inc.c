// 0x0E000408
const GeoLayout geo_bitdw_000408[] = {
   GEO_CULLING_RADIUS(4000),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bitdw_seg7_dl_07003BF0),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
