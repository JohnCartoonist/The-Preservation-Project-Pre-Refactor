// 0x0E0004B0
const GeoLayout geo_bitdw_0004B0[] = {
   GEO_CULLING_RADIUS(2400),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bitdw_seg7_dl_07008FF0),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
