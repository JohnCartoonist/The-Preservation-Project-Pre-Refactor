// 0x0E000540
const GeoLayout geo_bitdw_000540[] = {
   GEO_CULLING_RADIUS(1100),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bitdw_seg7_dl_0700B220),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
