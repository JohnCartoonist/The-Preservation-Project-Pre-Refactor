// 0x0E00070C
const GeoLayout castle_grounds_geo_00070C[] = {
   GEO_CULLING_RADIUS(15000),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_ALPHA, castle_grounds_seg7_dl_0700BB80),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
