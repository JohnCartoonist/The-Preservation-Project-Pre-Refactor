enum ConsoleType {
    CONSOLE_N64,
    CONSOLE_IQUE
};

extern enum ConsoleType gConsoleType;
extern enum ConsoleType get_console_type(void);
