# IMPORTANT NOTICE ABOUT THIS FOLDER

Everything in this folder is non-canon to the source code in the rest of the repository. As such, it is not to be considered when looking for more information on Super Mario 64's functionality.
