#ifndef UTF8_H_
#define UTF8_H_

char *utf8_decode(char *str, uint32_t *codep);

#endif // UTF8_H_
